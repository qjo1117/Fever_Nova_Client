using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour
{
    public GameObject player;
    private Vector3 positionOffset;

    private void Start()
    {
        positionOffset = transform.position - player.transform.position;
    }

    private void LateUpdate()
    {
        transform.position = Vector3.Lerp(transform.position,
            player.transform.position + positionOffset, Time.deltaTime * 2);
    }
}
