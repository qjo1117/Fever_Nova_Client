using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int player_hp = 5;
    public float moveSpeed;
    void Update()
    {
        float Horizontal = Input.GetAxisRaw("Horizontal");
        float Vertical = Input.GetAxisRaw("Vertical");

        if (Horizontal == 0 && Vertical == 0)
        {
            return;
        }
        
        Vector3 moveVector = new Vector3(Horizontal, 0, Vertical);
        transform.rotation = Quaternion.LookRotation(moveVector);
        transform.position += (moveVector.normalized * moveSpeed * Time.deltaTime);
    }
}
