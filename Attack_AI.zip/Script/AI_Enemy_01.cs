using System.Collections.Generic;
using UnityEngine;

public class AI_Enemy_01 : MonoBehaviour
{
    public GameObject club;
    public Transform Attack_transform;
    //��ų ��Ÿ��
    public float skill_cooltime=5f;
    //��������
    public float Detect_Range;
    //���ݹ���
    public float Attack_Range;
    //�߰� ���� 
    public float Chase_MoveSpeed;
    //���� �ӵ�
    public float Patrol_MoveSpeed;
    //���� ��������Ʈ
    public List<Vector3> Patrol_WaypointList;

    public Material material1;
    public Material material2;

    private BT_Root m_Brain;

    private GameObject Debug_DetectRange = null;
    private GameObject Debug_AttackRange = null;
    private GameObject Debug_Waypoints = null;
 
    public void Debug()
    {
        if (Debug_DetectRange != null)
        {
            DestroyImmediate(Debug_Waypoints);
        }
        if (Debug_DetectRange == null)
        {
            Debug_DetectRange = new GameObject();
            Debug_DetectRange.name = "Detect Range";
            Debug_DetectRange.transform.parent = gameObject.transform;
            Debug_DetectRange.AddComponent<LineRenderer>();

            Debug_AttackRange = new GameObject();
            Debug_AttackRange.name = "Attack Range";
            Debug_AttackRange.transform.parent = gameObject.transform;
            Debug_AttackRange.AddComponent<LineRenderer>();
        }

        LineRenderer Line_DetectRange = Debug_DetectRange.GetComponent<LineRenderer>();
        Line_DetectRange.useWorldSpace = false;
        Line_DetectRange.startColor = Color.yellow;
        Line_DetectRange.endColor = Color.yellow;
        Line_DetectRange.startWidth = 0.1f;
        Line_DetectRange.endWidth = 0.1f;
        Line_DetectRange.loop = true;
        Line_DetectRange.positionCount = 128;
        Line_DetectRange.material = material1;

        LineRenderer Line_AttackRange = Debug_AttackRange.GetComponent<LineRenderer>();
        Line_AttackRange.useWorldSpace = false;
        Line_AttackRange.startColor = Color.red;
        Line_AttackRange.endColor = Color.red;
        Line_AttackRange.startWidth = 0.1f;
        Line_AttackRange.endWidth = 0.1f;
        Line_AttackRange.loop = true;
        Line_AttackRange.positionCount = 128;
        Line_AttackRange.material = material1;


        float deltaTheta = (float)(2.0 * Mathf.PI) / 128;
        float theta = 0f;
        float x;
        float z;

        for (int i = 0; i < 128; i++)
        {
            x = Detect_Range * Mathf.Cos(theta);
            z = Detect_Range * Mathf.Sin(theta);
            Vector3 Pos = new Vector3(x, 0, z);
            Line_DetectRange.SetPosition(i, Pos);
            theta += deltaTheta;
        }

        for (int i = 0; i < 128; i++)
        {
            x = Attack_Range * Mathf.Cos(theta);
            z = Attack_Range * Mathf.Sin(theta);
            Vector3 Pos2 = new Vector3(x, 0, z);
            Line_AttackRange.SetPosition(i, Pos2);
            theta += deltaTheta;
        }



        Line_DetectRange.gameObject.transform.position = transform.position;
        Line_DetectRange.gameObject.transform.rotation = Quaternion.identity;

        Line_AttackRange.gameObject.transform.position = transform.position;
        Line_AttackRange.gameObject.transform.rotation = Quaternion.identity;


        if (Debug_Waypoints != null)
        {
            DestroyImmediate(Debug_Waypoints);
        }
        if (Debug_Waypoints == null)
        {
            Debug_Waypoints = new GameObject();
            Debug_Waypoints.name = "Way Points";
            Debug_Waypoints.transform.parent = gameObject.transform.parent.transform;
            Debug_Waypoints.transform.position = Vector3.zero;
        }

        for (int i = 0; i < Patrol_WaypointList.Count; i++)
        {
            GameObject Obj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Obj.name = "Way Point " + (i + 1);
            Obj.transform.parent = Debug_Waypoints.transform;
            Obj.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
            Obj.transform.position = Patrol_WaypointList[i];
            Obj.GetComponent<MeshRenderer>().material = material2;


            Obj.AddComponent<LineRenderer>();
            LineRenderer Line_WayPoint = Obj.GetComponent<LineRenderer>();
            Line_WayPoint.useWorldSpace = true;
            Line_WayPoint.startColor = Color.cyan;
            Line_WayPoint.endColor = Color.cyan;
            Line_WayPoint.startWidth = 0.1f;
            Line_WayPoint.endWidth = 0.1f;
            Line_WayPoint.loop = false;
            Line_WayPoint.positionCount = 2;
            Line_WayPoint.material = material1;

            Line_WayPoint.SetPosition(0, Obj.transform.position);
           
             if (i == Patrol_WaypointList.Count - 1)
            {
                Line_WayPoint.SetPosition(1, Patrol_WaypointList[0]);
            }
            else
            {
                Line_WayPoint.SetPosition(1, Patrol_WaypointList[i + 1]);
            }
        }
    }

    private void Start()
    {
        club.transform.position = Attack_transform.position;
        club.transform.SetParent(this.gameObject.transform);
        club.SetActive(false);
       CreateBehaviorTreeAIState();
    }

    private void Update()
    {
        m_Brain.Tick();
        
    }

    void CreateBehaviorTreeAIState()
    {
        m_Brain = new BT_Root();

        BT_Selector l_mainSelector = new BT_Selector();


        BT_Sequence l_MoveSQ = new BT_Sequence();

        BT_Sequence I_AttackSQ = new BT_Sequence();

        AI_Combat_Detect l_detect
            = new AI_Combat_Detect(gameObject, Detect_Range);

        AI_Combat_Chase l_chase
            = new AI_Combat_Chase(gameObject, Chase_MoveSpeed);

        l_MoveSQ.AddChild(l_detect);
        l_MoveSQ.AddChild(l_chase);


        Attack_Condition A_CON = new Attack_Condition(gameObject, Attack_Range);
        AI_Combat_attack A_ATTACK = new AI_Combat_attack(gameObject,club, skill_cooltime,Attack_transform);

        I_AttackSQ.AddChild(A_CON);
        I_AttackSQ.AddChild(A_ATTACK);

        BT_Sequence l_patrolSQ = new BT_Sequence();

        AI_Patrol_Waypoint l_patrol
            = new AI_Patrol_Waypoint(gameObject, Patrol_MoveSpeed, Patrol_WaypointList);

        l_patrolSQ.AddChild(l_patrol);

        l_mainSelector.AddChild(I_AttackSQ);
        l_mainSelector.AddChild(l_MoveSQ);
        l_mainSelector.AddChild(l_patrolSQ);

        m_Brain.Child = l_mainSelector;
    }
}
