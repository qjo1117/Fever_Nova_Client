using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(AI_Enemy_01))]
public class Debug_AI_Enemy_01 : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        AI_Enemy_01 m_AI = target as AI_Enemy_01;

        m_AI.Debug();
    }
}
